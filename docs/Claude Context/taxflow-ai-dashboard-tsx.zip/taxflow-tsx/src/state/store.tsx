import React, { createContext, useContext, useReducer, useCallback, useRef } from 'react';
import type {
  Client, InvoiceDoc, VaultFile, ChatMsg, Reminder, FilingTask, Bill, CheckItem, LogEntry, Page,
} from '../types';
import {
  CLIENTS, DOCS, FILES, TPL, REMINDERS, TASKS, BILLS, CHECKS, seedThreads, INITIAL_LOG,
} from '../data/seed';
import { vnow, ago } from '../lib/format';
import { nextTaskFor, pendingBill, missing } from '../lib/domain';

export interface Settings {
  autoExtract: boolean;
  autoRemind: boolean;
  approve: boolean;
  dupes: boolean;
}

export interface AppState {
  page: Page;
  theme: 'dark' | 'light';
  chatOpen: boolean;
  clients: Client[];
  docs: InvoiceDoc[];
  files: VaultFile[];
  threads: Record<string, ChatMsg[]>;
  reminders: Reminder[];
  tasks: FilingTask[];
  bills: Bill[];
  checks: Record<string, CheckItem[]>;
  log: LogEntry[];
  settings: Settings;
  ui: {
    wa: { client: string; tab: 'chats' | 'reminders' | 'templates' };
    ex: { sel: string; filter: string };
    fs: { open: Set<string>; sel: string | null; q: string };
    dl: { open: Set<string> };
    gen: { client: string; period: string; types: Set<string> };
  };
}

type Action =
  | { type: 'GO'; page: Page }
  | { type: 'TOGGLE_THEME' }
  | { type: 'TOGGLE_CHAT' }
  | { type: 'WA_CLIENT'; id: string }
  | { type: 'WA_TAB'; tab: 'chats' | 'reminders' | 'templates' }
  | { type: 'WA_SEND'; client: string; text: string }
  | { type: 'WA_APPEND'; client: string; msg: ChatMsg }
  | { type: 'REM_SCHEDULE'; reminder: Reminder }
  | { type: 'REM_SEND_NOW'; id: string }
  | { type: 'REM_CANCEL'; id: string }
  | { type: 'REM_APPROVE'; id: string }
  | { type: 'EX_SELECT'; id: string }
  | { type: 'EX_FILTER'; filter: string }
  | { type: 'EX_RUN_START'; id: string }
  | { type: 'EX_RUN_DONE'; id: string }
  | { type: 'EX_APPROVE'; id: string }
  | { type: 'EX_EDIT_FIELD'; id: string; field: string; value: string | number }
  | { type: 'FS_TOGGLE'; key: string }
  | { type: 'FS_SELECT'; id: string | null }
  | { type: 'FS_QUERY'; q: string }
  | { type: 'DL_TOGGLE'; client: string }
  | { type: 'STEP_TOGGLE'; taskId: string; index: number }
  | { type: 'GEN_CLIENT'; client: string }
  | { type: 'GEN_PERIOD'; period: string }
  | { type: 'GEN_TOGGLE_TYPE'; id: string }
  | { type: 'BILL_PAID'; no: string }
  | { type: 'SETTING_TOGGLE'; key: keyof Settings }
  | { type: 'LOG'; entry: LogEntry };

const initialState: AppState = {
  page: 'dashboard',
  theme: 'dark',
  chatOpen: true,
  clients: CLIENTS,
  docs: DOCS,
  files: FILES,
  threads: seedThreads(),
  reminders: REMINDERS,
  tasks: TASKS,
  bills: BILLS,
  checks: CHECKS,
  log: INITIAL_LOG,
  settings: { autoExtract: true, autoRemind: true, approve: true, dupes: true },
  ui: {
    wa: { client: 'sharma', tab: 'chats' },
    ex: { sel: 'd3', filter: 'all' },
    fs: { open: new Set(['c:sharma', 'y:sharma:2026', 'm:sharma:2026:8']), sel: null, q: '' },
    dl: { open: new Set(['kapoor', 'sharma']) },
    gen: { client: 'iyer', period: '2026-08', types: new Set(['gstr3b', 'recon', 'reg']) },
  },
};

let MID = 1000;

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'GO':
      return { ...state, page: action.page };
    case 'TOGGLE_THEME':
      return { ...state, theme: state.theme === 'dark' ? 'light' : 'dark' };
    case 'TOGGLE_CHAT':
      return { ...state, chatOpen: !state.chatOpen };
    case 'WA_CLIENT':
      return { ...state, ui: { ...state.ui, wa: { ...state.ui.wa, client: action.id } } };
    case 'WA_TAB':
      return { ...state, ui: { ...state.ui, wa: { ...state.ui.wa, tab: action.tab } } };
    case 'WA_APPEND': {
      const thread = state.threads[action.client] || [];
      return { ...state, threads: { ...state.threads, [action.client]: [...thread, action.msg] } };
    }
    case 'REM_SCHEDULE':
      return {
        ...state,
        reminders: [...state.reminders, action.reminder],
        log: [{ at: vnow(), ic: 'bell', t: `Scheduled a reminder for ${action.reminder.client}` }, ...state.log],
      };
    case 'REM_SEND_NOW': {
      const r = state.reminders.find((x) => x.id === action.id);
      if (!r) return state;
      const thread = state.threads[r.client] || [];
      const msg: ChatMsg = { id: MID++, f: 'me', t: r.text, at: vnow(), st: 'delivered', auto: true };
      return {
        ...state,
        reminders: state.reminders.map((x) => (x.id === action.id ? { ...x, status: 'sent' } : x)),
        threads: { ...state.threads, [r.client]: [...thread, msg] },
        log: [{ at: vnow(), ic: 'send', t: `Sent a reminder to ${r.client}` }, ...state.log],
      };
    }
    case 'REM_CANCEL':
      return { ...state, reminders: state.reminders.map((x) => (x.id === action.id ? { ...x, status: 'cancelled' } : x)) };
    case 'REM_APPROVE':
      return { ...state, reminders: state.reminders.map((x) => (x.id === action.id ? { ...x, approve: false } : x)) };
    case 'EX_SELECT':
      return { ...state, ui: { ...state.ui, ex: { ...state.ui.ex, sel: action.id } } };
    case 'EX_FILTER':
      return { ...state, ui: { ...state.ui, ex: { ...state.ui.ex, filter: action.filter } } };
    case 'EX_RUN_START':
      return { ...state, docs: state.docs.map((d) => (d.id === action.id ? { ...d, running: true } : d)) };
    case 'EX_RUN_DONE':
      return {
        ...state,
        docs: state.docs.map((d) => (d.id === action.id ? { ...d, running: false, status: d.low ? 'review' : 'extracted' } : d)),
        log: [{ at: vnow(), ic: 'scan', t: `Extracted invoice ${action.id}` }, ...state.log],
      };
    case 'EX_APPROVE':
      return {
        ...state,
        docs: state.docs.map((d) =>
          d.id === action.id
            ? { ...d, status: 'approved', conf: Object.fromEntries(Object.entries(d.conf).map(([k, v]) => [k, v < 0.8 ? 1 : v])) }
            : d
        ),
        log: [{ at: vnow(), ic: 'check', t: `Approved invoice ${action.id}` }, ...state.log],
      };
    case 'EX_EDIT_FIELD':
      return {
        ...state,
        docs: state.docs.map((d) => {
          if (d.id !== action.id) return d;
          const next: any = { ...d, conf: { ...d.conf, [action.field]: 1 } };
          if (action.field === 'taxable' || action.field === 'rate') next[action.field] = Number(action.value);
          else next[action.field] = action.value;
          if (next.status === 'approved') next.status = 'extracted';
          return next;
        }),
      };
    case 'FS_TOGGLE': {
      const open = new Set(state.ui.fs.open);
      open.has(action.key) ? open.delete(action.key) : open.add(action.key);
      return { ...state, ui: { ...state.ui, fs: { ...state.ui.fs, open } } };
    }
    case 'FS_SELECT':
      return { ...state, ui: { ...state.ui, fs: { ...state.ui.fs, sel: action.id } } };
    case 'FS_QUERY':
      return { ...state, ui: { ...state.ui, fs: { ...state.ui.fs, q: action.q } } };
    case 'DL_TOGGLE': {
      const open = new Set(state.ui.dl.open);
      open.has(action.client) ? open.delete(action.client) : open.add(action.client);
      return { ...state, ui: { ...state.ui, dl: { open } } };
    }
    case 'STEP_TOGGLE':
      return {
        ...state,
        tasks: state.tasks.map((t) =>
          t.id === action.taskId ? { ...t, steps: t.steps.map((s, i) => (i === action.index ? !s : s)) } : t
        ),
      };
    case 'GEN_CLIENT':
      return { ...state, ui: { ...state.ui, gen: { ...state.ui.gen, client: action.client } } };
    case 'GEN_PERIOD':
      return { ...state, ui: { ...state.ui, gen: { ...state.ui.gen, period: action.period } } };
    case 'GEN_TOGGLE_TYPE': {
      const types = new Set(state.ui.gen.types);
      types.has(action.id) ? types.delete(action.id) : types.add(action.id);
      return { ...state, ui: { ...state.ui, gen: { ...state.ui.gen, types } } };
    }
    case 'BILL_PAID':
      return { ...state, bills: state.bills.map((b) => (b.no === action.no ? { ...b, status: 'paid' } : b)) };
    case 'SETTING_TOGGLE':
      return { ...state, settings: { ...state.settings, [action.key]: !state.settings[action.key] } };
    case 'LOG':
      return { ...state, log: [action.entry, ...state.log] };
    default:
      return state;
  }
}

const StateCtx = createContext<AppState>(initialState);
const DispatchCtx = createContext<React.Dispatch<Action>>(() => {});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <StateCtx.Provider value={state}>
      <DispatchCtx.Provider value={dispatch}>{children}</DispatchCtx.Provider>
    </StateCtx.Provider>
  );
}

export const useAppState = () => useContext(StateCtx);
export const useDispatch = () => useContext(DispatchCtx);

export function nextMsgId() {
  return MID++;
}

// Convenience selectors
export function useClient(id: string) {
  const s = useAppState();
  return s.clients.find((c) => c.id === id)!;
}
