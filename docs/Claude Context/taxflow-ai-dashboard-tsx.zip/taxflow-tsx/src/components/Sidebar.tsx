import { Icon } from './Icon';
import { useAppState, useDispatch } from '../state/store';
import type { Page } from '../types';
import { allTasks } from '../lib/domain';
import { dayDiff, vnow } from '../lib/format';

const NAV: Array<{ g: string; items: Array<[Page, string, string]> }> = [
  { g: 'Workspace', items: [['dashboard', 'Dashboard', 'grid']] },
  {
    g: 'Automation',
    items: [
      ['extract', 'Invoice extraction', 'scan'],
      ['whatsapp', 'WhatsApp', 'chat'],
      ['files', 'Client folders', 'folder'],
      ['deadlines', 'Deadlines', 'cal'],
      ['generate', 'File generator', 'spark'],
    ],
  },
  {
    g: 'Practice',
    items: [
      ['clients', 'Clients', 'users'],
      ['billing', 'Billing & fees', 'rupee'],
      ['settings', 'Settings', 'sliders'],
    ],
  },
];

export function Sidebar() {
  const s = useAppState();
  const dispatch = useDispatch();

  const badge = (id: Page): { n: number; hot?: boolean } | null => {
    if (id === 'extract') {
      const n = s.docs.filter((d) => d.status === 'queued' || d.status === 'review').length;
      return n ? { n } : null;
    }
    if (id === 'whatsapp') {
      const n = s.reminders.filter((r) => r.status === 'scheduled' && dayDiff(r.at, vnow()) === 0).length;
      return n ? { n } : null;
    }
    if (id === 'deadlines') {
      const n = allTasks(s.tasks).filter((x) => x.st === 'overdue').length;
      return n ? { n, hot: true } : null;
    }
    return null;
  };

  return (
    <nav className="side" aria-label="Pages">
      {NAV.map((g) => (
        <div key={g.g}>
          <div className="gtitle">{g.g}</div>
          {g.items.map(([id, label, icon]) => {
            const b = badge(id);
            return (
              <button
                key={id}
                className={'nav' + (s.page === id ? ' on' : '')}
                onClick={() => dispatch({ type: 'GO', page: id })}
                title={label}
              >
                <Icon name={icon} size={17} />
                <span className="lb">{label}</span>
                {b && <span className={'bd' + (b.hot ? ' hot' : '')}>{b.n}</span>}
              </button>
            );
          })}
        </div>
      ))}
      <div className="vault">
        <b>Local vault</b>
        <span>D:\Taxflow · {(3.2 + s.files.length / 1000).toFixed(1)} GB of 500 GB</span>
        <div style={{ marginTop: 8 }}>
          <div className="bar"><i style={{ width: '1%' }} /></div>
        </div>
      </div>
      <div className="me">
        <span className="av" style={{ ['--t' as any]: '#4C8DFF' }}>DF</span>
        <div>
          <b>Demo Firm &amp; Associates</b>
          <small>Partner account</small>
        </div>
      </div>
    </nav>
  );
}
