import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';
import { useAppState, useDispatch } from '../state/store';
import { allTasks, missing } from '../lib/domain';
import { fDate } from '../lib/format';
import type { Page } from '../types';

interface Msg { id: number; who: 'me' | 'ai'; html: string }
let MID = 1;

const SUGG = [
  'What is due this week?',
  'Who has not sent documents?',
  'Extract queued invoices',
  'Show Sharma Traders folder',
  'Outstanding fees',
];

export function Chat() {
  const s = useAppState();
  const dispatch = useDispatch();
  const [msgs, setMsgs] = useState<Msg[]>([
    { id: MID++, who: 'ai', html: 'Hello. Ask me about deadlines, missing documents, invoices, folders or fees, and I\u2019ll open the right page.' },
  ]);
  const [input, setInput] = useState('');
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => { boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight }); }, [msgs.length]);

  function go(page: Page, label: string) {
    dispatch({ type: 'GO', page });
    return `<div><button class="opened">→ Opened ${label}</button></div>`;
  }

  function detectClient(q: string) {
    const t = q.toLowerCase();
    return s.clients.find((c) => c.alias.some((a) => new RegExp(`\\b${a}\\b`).test(t)) || t.includes(c.name.toLowerCase()));
  }

  function answer(q: string): string {
    const t = q.toLowerCase();
    const c = detectClient(q);
    const ti = allTasks(s.tasks);

    if (/missing|not sent|pending doc/.test(t)) {
      const m = s.clients.filter((x) => missing(s.checks, x.id).length);
      const opened = go('whatsapp', 'WhatsApp');
      return `<b>${m.length} of ${s.clients.length} clients</b> still owe documents:<ul>${m.map((x) => `<li><b>${x.short}</b>: ${missing(s.checks, x.id).map((y) => y.n).join(', ')}</li>`).join('')}</ul>${opened}`;
    }
    if (/extract|invoice|bill\b|scan/.test(t)) {
      const q1 = s.docs.filter((d) => d.status === 'queued');
      const opened = go('extract', 'Invoice extraction');
      return `There ${q1.length === 1 ? 'is' : 'are'} <b>${q1.length}</b> invoice${q1.length === 1 ? '' : 's'} queued for extraction.${opened}`;
    }
    if (/folder|files|vault|storage/.test(t)) {
      const cc = c || s.clients[0];
      const opened = go('files', 'Client folders');
      const fl = s.files.filter((f) => f.client === cc.id);
      return `<b>${cc.name}</b> has ${fl.length} files on record.${opened}`;
    }
    if (/whatsapp|chat|message/.test(t)) {
      if (c) dispatch({ type: 'WA_CLIENT', id: c.id });
      const opened = go('whatsapp', 'WhatsApp');
      return c ? `Here is the conversation with <b>${c.name}</b>.${opened}` : `Here are all your client chats.${opened}`;
    }
    if (/fee|billing|outstanding|payment/.test(t)) {
      const opened = go('billing', 'Billing & fees');
      const ov = s.bills.filter((b) => b.status === 'overdue');
      return `<b>${ov.length}</b> fee invoices are overdue.${opened}`;
    }
    if (/deadline|due|overdue|progress|filing/.test(t)) {
      const opened = go('deadlines', 'Deadlines');
      const list = ti.filter((x) => x.st !== 'done' && x.days <= 7).sort((a, b) => a.days - b.days);
      return `<b>${list.length}</b> filings are due within 7 days or overdue.${opened}`;
    }
    if (/generate|gstr|itr|tds|vat|register/.test(t)) {
      const opened = go('generate', 'File generator');
      return `Opening the file generator for you.${opened}`;
    }
    if (/client|clients/.test(t)) {
      const opened = go('clients', 'Clients');
      return `You have <b>${s.clients.length}</b> active clients.${opened}`;
    }
    const over = ti.filter((x) => x.st === 'overdue').length;
    const week = ti.filter((x) => x.st !== 'done' && x.days >= 0 && x.days <= 7).length;
    const opened = go('dashboard', 'Dashboard');
    return `Today: <b>${over} overdue</b>, <b>${week}</b> filings due within 7 days.${opened}`;
  }

  function ask(q: string) {
    q = q.trim();
    if (!q) return;
    setMsgs((m) => [...m, { id: MID++, who: 'me', html: q }]);
    setTimeout(() => setMsgs((m) => [...m, { id: MID++, who: 'ai', html: answer(q) }]), 500);
  }

  return (
    <aside className="chat" aria-label="Assistant">
      <div className="ch-h">
        <span className="logo"><Icon name="spark" size={16} /></span>
        <div><b>Taxflow Assistant</b><small>Checks your workspace and opens the right page</small></div>
      </div>
      <div id="ai-msgs" ref={boxRef}>
        {msgs.map((m) => (
          <div key={m.id} className={'cm ' + (m.who === 'me' ? 'me' : 'ai')} dangerouslySetInnerHTML={{ __html: m.html }} />
        ))}
      </div>
      <div className="sugg">
        {SUGG.map((q) => <button key={q} onClick={() => ask(q)}>{q}</button>)}
      </div>
      <div className="ch-f">
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { ask(input); setInput(''); } }} placeholder="Ask anything about your clients or work" />
        <button className="btn pri" onClick={() => { ask(input); setInput(''); }} aria-label="Send"><Icon name="send" size={16} /></button>
      </div>
    </aside>
  );
}
