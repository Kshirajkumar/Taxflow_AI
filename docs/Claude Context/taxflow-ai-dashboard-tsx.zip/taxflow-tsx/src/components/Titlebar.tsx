import { useState } from 'react';
import { Icon } from './Icon';
import { useAppState, useDispatch } from '../state/store';

export function Titlebar() {
  const s = useAppState();
  const dispatch = useDispatch();
  const [q, setQ] = useState('');

  const results = q.trim()
    ? s.clients
        .filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) || c.gstin.toLowerCase().includes(q.toLowerCase()))
        .slice(0, 8)
    : [];

  return (
    <header className="titlebar">
      <div className="brand">
        <span className="logo">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 19V9M10 19V5M16 19v-7M22 19H2" />
          </svg>
        </span>
        Taxflow.AI <small>CA Practice Suite</small>
      </div>
      <div className="gsearch">
        <span className="gi"><Icon name="search" size={14} /></span>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search clients, invoices, files"
          autoComplete="off"
          aria-label="Search workspace"
        />
        {results.length > 0 && (
          <div className="gres">
            {results.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  dispatch({ type: 'WA_CLIENT', id: c.id });
                  dispatch({ type: 'GO', page: 'whatsapp' });
                  setQ('');
                }}
              >
                <Icon name="users" size={16} />
                <span>
                  <b>{c.name}</b>
                  <small>{c.city}</small>
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
      <div />
      <div className="wc">
        <button onClick={() => dispatch({ type: 'TOGGLE_THEME' })} title="Switch theme" aria-label="Switch theme">
          <Icon name={s.theme === 'dark' ? 'sun' : 'moon'} size={16} />
        </button>
        <button onClick={() => dispatch({ type: 'TOGGLE_CHAT' })} title="Toggle assistant" aria-label="Toggle assistant">
          <Icon name="panel" size={16} />
        </button>
        <button title="Minimize" aria-label="Minimize"><svg width="10" height="10"><path d="M0 5h10" stroke="currentColor" /></svg></button>
        <button title="Maximize" aria-label="Maximize"><svg width="10" height="10"><rect x=".5" y=".5" width="9" height="9" fill="none" stroke="currentColor" /></svg></button>
        <button className="x" title="Close" aria-label="Close"><svg width="10" height="10"><path d="M0 0l10 10M10 0L0 10" stroke="currentColor" /></svg></button>
      </div>
    </header>
  );
}
